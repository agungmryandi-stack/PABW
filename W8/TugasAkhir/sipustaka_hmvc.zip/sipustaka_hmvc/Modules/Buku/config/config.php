<?php

return [
    'name' => 'Buku',
];
