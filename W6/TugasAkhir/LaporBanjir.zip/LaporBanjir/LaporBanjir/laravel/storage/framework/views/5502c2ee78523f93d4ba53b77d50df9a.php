<div class="card status-<?php echo e(strtolower($laporan->status)); ?>">
    <div class="card-top">
        <span class="badge badge-<?php echo e(strtolower($laporan->status)); ?>"><?php echo e($laporan->status); ?></span>
        <span class="tgl"><?php echo e($laporan->tanggal_kejadian->format('d M Y')); ?></span>
    </div>
    <h3>📍 <?php echo e($laporan->lokasi); ?></h3>
    <p class="tinggi"><?php echo e($laporan->tinggi_genangan); ?> <small>cm</small></p>
    <p class="pelapor">Dilaporkan oleh <?php echo e($laporan->nama_pelapor); ?></p>
</div><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W4\TugasAkhir\LaporBanjir\laravel\resources\views/partials/laporan-card.blade.php ENDPATH**/ ?>