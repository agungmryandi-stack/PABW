<?php $__env->startSection('title', 'Lapor Banjir'); ?>

<?php $__env->startSection('content'); ?>
<div class="dua-kolom">

    <section class="formulir">
        <div class="formulir-kop">Formulir laporan genangan</div>

        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <form action="/simpan" method="POST">
            <?php echo csrf_field(); ?>

            <div class="isian">
                <label>01 &middot; Nama Pelapor</label>
                <input type="text" name="nama_pelapor" value="<?php echo e(old('nama_pelapor')); ?>" placeholder="Contoh: Budi Santoso">
            </div>

            <div class="isian">
                <label>02 &middot; Lokasi (Kecamatan)</label>
                <select name="lokasi">
                    <option value="">-- Pilih kecamatan --</option>
                    <?php $__currentLoopData = ['Dayeuhkolot', 'Baleendah', 'Bojongsoang', 'Rancaekek', 'Majalaya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kec); ?>" <?php echo e(old('lokasi') == $kec ? 'selected' : ''); ?>><?php echo e($kec); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="isian">
                <label>03 &middot; Tinggi Genangan (cm)</label>
                <input type="number" name="tinggi_genangan" value="<?php echo e(old('tinggi_genangan')); ?>" placeholder="Contoh: 60">
            </div>

            <div class="isian">
                <label>04 &middot; Tanggal Kejadian</label>
                <input type="date" name="tanggal_kejadian" value="<?php echo e(old('tanggal_kejadian')); ?>">
            </div>

            <button type="submit" class="tombol tombol-penuh">Kirim Laporan</button>
        </form>
    </section>

    <aside class="catatan">
        <p class="kecil">Untuk warga</p>
        <h1 class="judul-halaman">Laporkan genangan di sekitar Anda.</h1>
        <p class="lead">Tidak perlu login. Isi data dengan benar agar petugas BPBD dapat menilai tingkat bahayanya.</p>

        <h3 style="margin-top:32px">Cara membaca status</h3>
        <?php echo $__env->make('partials.skala', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <p style="margin-top:14px">Ukur tinggi air dari permukaan tanah ke batas air terdalam yang terlihat.</p>
    </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/form.blade.php ENDPATH**/ ?>