<?php $__env->startSection('title', 'Login ' . ucfirst($role)); ?>

<?php $__env->startSection('content'); ?>
<div class="masuk masuk-<?php echo e($role); ?>">

    
    <section>
        <div class="tab-peran">
            <a href="/login/petugas" class="<?php echo e($role == 'petugas' ? 'aktif' : ''); ?>">Petugas</a>
            <a href="/login/admin" class="<?php echo e($role == 'admin' ? 'aktif' : ''); ?>">Admin</a>
        </div>

        <?php if($role == 'admin'): ?>
            <h1>Ruang kendali admin BPBD.</h1>
            <p class="lead">Admin dapat membuka semua halaman petugas dan mengelola akun petugas.</p>
        <?php else: ?>
            <h1>Masuk untuk memantau laporan genangan.</h1>
            <p class="lead">Petugas dapat membuka Daftar Laporan dan Profil Petugas. Gunakan akun yang sudah terdaftar.</p>
        <?php endif; ?>

        <?php echo $__env->make('partials.skala', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>

    
    <section class="formulir">
        <div class="formulir-kop">Login <?php echo e($role); ?></div>

        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <form action="/login/<?php echo e($role); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="isian">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>">
            </div>

            <div class="isian">
                <label>Password</label>
                <input type="password" name="password">
            </div>

            <button type="submit" class="tombol tombol-penuh">Login</button>
        </form>

        <p class="pindah">Belum punya akun? <a href="/register/<?php echo e($role); ?>">Register <?php echo e($role); ?></a></p>
    </section>
</div>


<div class="warga">
    <p><strong>Anda warga?</strong><br>
       Laporkan genangan di sekitar Anda langsung lewat formulir, tanpa perlu login.</p>
    <a href="/form" class="tombol tombol-garis">Lapor Banjir</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>