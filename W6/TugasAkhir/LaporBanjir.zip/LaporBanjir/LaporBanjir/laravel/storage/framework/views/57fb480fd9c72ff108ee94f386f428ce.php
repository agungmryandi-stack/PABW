<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<div class="beranda">

    
    <section>
        <p class="kecil">Ringkasan laporan &middot; <?php echo e(now()->format('d/m/Y')); ?></p>

        <h1 class="judul-besar">
            <span class="angka-awas"><?php echo e($awas); ?></span> laporan berstatus Awas
            dari <?php echo e($total); ?> laporan yang masuk.
        </h1>

        <?php if($tertinggi): ?>
            <p class="lead">
                Genangan tertinggi tercatat <strong><?php echo e($tertinggi->tinggi_genangan); ?> cm</strong>
                di <?php echo e($tertinggi->lokasi); ?> (<?php echo e($tertinggi->tanggal_kejadian->format('d M Y')); ?>).
            </p>
        <?php else: ?>
            <p class="lead">Belum ada laporan yang masuk.</p>
        <?php endif; ?>

        <div class="hitung">
            <div><b><?php echo e($total); ?></b><span>Total</span></div>
            <div class="h-awas"><b><?php echo e($awas); ?></b><span>Awas</span></div>
            <div class="h-siaga"><b><?php echo e($siaga); ?></b><span>Siaga</span></div>
            <div class="h-waspada"><b><?php echo e($waspada); ?></b><span>Waspada</span></div>
        </div>

        <div class="tombol-baris">
            <a href="/daftar-laporan" class="tombol">Buka Daftar Laporan</a>
            <a href="/form" class="tombol tombol-garis">Isi Laporan Baru</a>
        </div>
    </section>

    
    <aside class="duga">
        <p class="kecil">Papan duga &middot; genangan tertinggi</p>

        <svg viewBox="0 0 280 370" role="img" aria-label="Papan duga tinggi genangan">
            
            <rect x="70" y="240" width="46" height="100" fill="#d9a521"/>
            <rect x="70" y="140" width="46" height="100" fill="#d9692a"/>
            <rect x="70" y="40"  width="46" height="100" fill="#b3281f"/>
            <rect x="70" y="40"  width="46" height="300" fill="none" stroke="#17232d" stroke-width="2"/>

            
            <?php for($cm = 0; $cm <= 150; $cm += 10): ?>
                <?php
                    $y = 340 - $cm * 2;
                    $panjang = ($cm % 50 == 0) ? 24 : 13;
                ?>
                <line x1="70" y1="<?php echo e($y); ?>" x2="<?php echo e(70 + $panjang); ?>" y2="<?php echo e($y); ?>" stroke="#17232d" stroke-width="1.5"/>
                <text x="62" y="<?php echo e($y + 3); ?>" text-anchor="end" class="duga-angka"><?php echo e($cm); ?></text>
            <?php endfor; ?>

            
            <text x="124" y="324" class="duga-zona">WASPADA</text>
            <text x="124" y="224" class="duga-zona">SIAGA</text>
            <text x="124" y="124" class="duga-zona">AWAS</text>

            
            <?php if($tertinggi): ?>
                <?php $yTanda = 340 - min(150, $tertinggi->tinggi_genangan) * 2; ?>
                <line x1="68" y1="<?php echo e($yTanda); ?>" x2="272" y2="<?php echo e($yTanda); ?>" stroke="#17232d" stroke-width="2.5"/>
                <circle cx="272" cy="<?php echo e($yTanda); ?>" r="4" fill="#17232d"/>
                <text x="272" y="<?php echo e($yTanda - 8); ?>" text-anchor="end" class="duga-nilai"><?php echo e($tertinggi->tinggi_genangan); ?> cm</text>
            <?php endif; ?>

            <text x="62" y="362" text-anchor="end" class="duga-angka">cm</text>
        </svg>
    </aside>
</div>

<h2 class="bagian">Laporan terbaru</h2>

<?php if($terbaru->count() > 0): ?>
    <div class="slip-grid">
        <?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.laporan-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <p class="kosong">Belum ada laporan masuk.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/beranda.blade.php ENDPATH**/ ?>