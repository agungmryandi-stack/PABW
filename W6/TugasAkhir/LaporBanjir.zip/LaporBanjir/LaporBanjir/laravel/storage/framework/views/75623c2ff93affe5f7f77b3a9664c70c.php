

<?php $__env->startSection('title', 'Lapor Banjir'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="judul" style="text-align:center">Form Pelaporan Banjir</h1>
    <p class="sub" style="text-align:center">Isi data berikut dengan benar dan lengkap.</p>

    <div class="form-box">
        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <form action="/simpan" method="POST">
            <?php echo csrf_field(); ?>

            <label>Nama Pelapor</label>
            <input type="text" name="nama_pelapor" value="<?php echo e(old('nama_pelapor')); ?>" placeholder="Contoh: Budi Santoso">

            <label>Lokasi (Kecamatan)</label>
            <select name="lokasi">
                <option value="">-- Pilih kecamatan --</option>
                <?php $__currentLoopData = ['Dayeuhkolot', 'Baleendah', 'Bojongsoang', 'Rancaekek', 'Majalaya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kec); ?>" <?php echo e(old('lokasi') == $kec ? 'selected' : ''); ?>><?php echo e($kec); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label>Tinggi Genangan (cm)</label>
            <input type="number" name="tinggi_genangan" value="<?php echo e(old('tinggi_genangan')); ?>" placeholder="Contoh: 60">

            <label>Tanggal Kejadian</label>
            <input type="date" name="tanggal_kejadian" value="<?php echo e(old('tanggal_kejadian')); ?>">

            <button type="submit" class="btn">Kirim Laporan</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W4\TugasAkhir\LaporBanjir\laravel\resources\views/form.blade.php ENDPATH**/ ?>