<?php $__env->startSection('title', 'Register ' . ucfirst($role)); ?>

<?php $__env->startSection('content'); ?>
<div class="masuk masuk-<?php echo e($role); ?>">

    <section>
        <div class="tab-peran">
            <a href="/register/petugas" class="<?php echo e($role == 'petugas' ? 'aktif' : ''); ?>">Petugas</a>
            <a href="/register/admin" class="<?php echo e($role == 'admin' ? 'aktif' : ''); ?>">Admin</a>
        </div>

        <?php if($role == 'admin'): ?>
            <h1>Daftar sebagai admin.</h1>
            <p class="lead">Pendaftaran admin memerlukan kode admin dari BPBD. Tanpa kode, akun tidak dapat dibuat.</p>
        <?php else: ?>
            <h1>Daftar sebagai petugas.</h1>
            <p class="lead">Akun petugas dapat membuka Daftar Laporan dan Profil Petugas setelah login.</p>
        <?php endif; ?>

        <?php echo $__env->make('partials.skala', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>

    <section class="formulir">
        <div class="formulir-kop">Register <?php echo e($role); ?></div>

        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <form action="/register/<?php echo e($role); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="isian">
                <label>Nama</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>">
            </div>

            <div class="isian">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>">
            </div>

            <div class="isian">
                <label>Password</label>
                <input type="password" name="password">
            </div>

            <div class="isian">
                <label>Konfirmasi Password</label>
                <input type="password" name="password_confirmation">
            </div>

            
            <?php if($role == 'admin'): ?>
                <div class="isian">
                    <label>Kode Admin</label>
                    <input type="password" name="kode_admin">
                </div>
            <?php endif; ?>

            <button type="submit" class="tombol tombol-penuh">Register</button>
        </form>

        <p class="pindah">Sudah punya akun? <a href="/login/<?php echo e($role); ?>">Login <?php echo e($role); ?></a></p>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>