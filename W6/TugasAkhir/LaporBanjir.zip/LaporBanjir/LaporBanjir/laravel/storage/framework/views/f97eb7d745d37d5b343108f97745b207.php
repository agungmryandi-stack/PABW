<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> - LaporBanjir</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/tema.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    
    <div class="pita">
        <div class="bungkus">
            <span>BPBD Kabupaten Bandung &middot; Posko Pelaporan Banjir</span>
            <?php if(auth()->guard()->check()): ?>
                <span><?php echo e(Auth::user()->name); ?> &middot; <?php echo e(Auth::user()->role); ?></span>
            <?php endif; ?>
        </div>
    </div>

    
    <header class="atas">
        <div class="bungkus">
            <a href="/" class="merek">
                <svg width="22" height="26" viewBox="0 0 24 28" aria-hidden="true">
                    <rect x="8" y="1" width="8" height="26" fill="none" stroke="currentColor" stroke-width="2"/>
                    <path d="M8 6h4M8 11h6M8 16h4M8 21h6" stroke="currentColor" stroke-width="2"/>
                    <path d="M0 19c3-2 5 2 8 0M16 19c3-2 5 2 8 0" stroke="#7fc1e3" stroke-width="2" fill="none"/>
                </svg>
                <span>Lapor<b>Banjir</b></span>
            </a>

            <nav class="menu">
                <?php if(auth()->guard()->check()): ?>
                    
                    <a href="/" class="<?php echo e(request()->is('/') ? 'aktif' : ''); ?>">Beranda</a>
                    <a href="/form" class="<?php echo e(request()->is('form') ? 'aktif' : ''); ?>">Lapor Banjir</a>
                    <a href="/daftar-laporan" class="<?php echo e(request()->is('daftar-laporan') ? 'aktif' : ''); ?>">Daftar Laporan</a>
                    <a href="/profil" class="<?php echo e(request()->is('profil') ? 'aktif' : ''); ?>">Profil Petugas</a>

                    
                    <?php if(Auth::user()->isAdmin()): ?>
                        <a href="/admin/petugas" class="<?php echo e(request()->is('admin/petugas') ? 'aktif' : ''); ?>">Kelola Petugas</a>
                    <?php endif; ?>

                    <form action="/logout" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Logout</button>
                    </form>
                <?php else: ?>
                    
                    <a href="/form" class="<?php echo e(request()->is('form') ? 'aktif' : ''); ?>">Lapor Banjir</a>
                    <a href="/login" class="<?php echo e(request()->is('login*') ? 'aktif' : ''); ?>">Login</a>
                    <a href="/register" class="<?php echo e(request()->is('register*') ? 'aktif' : ''); ?>">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="bungkus">
        <?php if(session('sukses')): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session('sukses')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if(session('galat')): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?><?php echo e(session('galat')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <div class="bungkus">
            <span>&copy; <?php echo e(date('Y')); ?> LaporBanjir</span>
            <span>Papan duga: Waspada &lt; 50 cm &middot; Siaga 50&ndash;99 cm &middot; Awas &ge; 100 cm</span>
        </div>
    </footer>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>