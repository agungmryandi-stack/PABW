<article class="slip slip-<?php echo e(strtolower($laporan->status)); ?>">
    <div class="slip-atas">
        <span class="cap cap-<?php echo e(strtolower($laporan->status)); ?>"><?php echo e($laporan->status); ?></span>
        <span class="tgl"><?php echo e($laporan->tanggal_kejadian->format('d M Y')); ?></span>
    </div>
    <h3><?php echo e($laporan->lokasi); ?></h3>
    <p class="slip-tinggi"><?php echo e($laporan->tinggi_genangan); ?> <small>cm</small></p>
    <p class="slip-pelapor">Pelapor: <?php echo e($laporan->nama_pelapor); ?></p>
</article>
<?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/partials/laporan-card.blade.php ENDPATH**/ ?>