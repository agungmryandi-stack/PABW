<?php $__env->startSection('title', 'Kelola Petugas'); ?>

<?php $__env->startSection('content'); ?>
<p class="kecil">Khusus admin</p>
<h1 class="judul-halaman">Kelola Petugas</h1>
<p class="lead" style="margin-bottom:24px">Daftar semua akun yang terdaftar (<?php echo e($users->count()); ?> akun).</p>

<div class="tabel-gulir">
    <table class="tabel">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Peran</th>
                <th>Dibuat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><span class="peran peran-<?php echo e($user->role); ?>"><?php echo e($user->role); ?></span></td>
                    <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td>
                        
                        <?php if($user->role == 'petugas'): ?>
                            <form action="/admin/petugas/<?php echo e($user->id); ?>" method="POST"
                                  onsubmit="return confirm('Hapus akun ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="tombol-hapus">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/admin/petugas.blade.php ENDPATH**/ ?>