

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero">
        <h1>Laporkan Banjir, Selamatkan Sesama</h1>
        <p>Sistem pelaporan banjir warga Kabupaten Bandung. Kirim laporan genangan di sekitar Anda
           agar petugas BPBD dapat bergerak lebih cepat.</p>
        <a href="/form" class="btn btn-putih">Buat Laporan</a>
    </div>

    <div class="stats">
        <div class="stat">
            <div class="angka"><?php echo e($total); ?></div>
            <div class="label">Total Laporan</div>
        </div>
        <div class="stat">
            <div class="angka" style="color: var(--awas)"><?php echo e($awas); ?></div>
            <div class="label">Status Awas</div>
        </div>
    </div>

    <h2 class="section-title">Laporan Terbaru</h2>
    <?php if($terbaru->count() > 0): ?>
        <div class="grid">
            <?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.laporan-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p class="kosong">Belum ada laporan masuk.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W4\TugasAkhir\LaporBanjir\laravel\resources\views/beranda.blade.php ENDPATH**/ ?>