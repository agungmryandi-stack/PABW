

<?php $__env->startSection('title', 'Daftar Laporan'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/daftar.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/daftar.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="lb-head">
    <div>
        <h1>Daftar Laporan Banjir</h1>
        <p>Rekap laporan warga berdasarkan tingkat status ketinggian genangan.</p>
    </div>
    <a href="/form" class="lb-btn">+ Buat Laporan</a>
</div>

<div class="lb-panel">
    <div class="lb-toolbar">
        <div class="lb-tabs" id="lbTabs">
            <button class="lb-tab active" data-filter="semua">Semua <span class="n"><?php echo e($jumlah['semua']); ?></span></button>
            <button class="lb-tab" data-filter="awas"><span class="dot dot-awas"></span>Awas <span class="n"><?php echo e($jumlah['awas']); ?></span></button>
            <button class="lb-tab" data-filter="siaga"><span class="dot dot-siaga"></span>Siaga <span class="n"><?php echo e($jumlah['siaga']); ?></span></button>
            <button class="lb-tab" data-filter="waspada"><span class="dot dot-waspada"></span>Waspada <span class="n"><?php echo e($jumlah['waspada']); ?></span></button>
        </div>

        <div class="lb-search">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="text" id="lbCari" placeholder="Cari lokasi atau pelapor...">
        </div>
    </div>

    <div class="lb-scroll">
        <table class="lb-table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Lokasi</th>
                    <th>Tinggi Genangan</th>
                    <th>Status</th>
                    <th>Pelapor</th>
                </tr>
            </thead>
            <tbody id="lbBody">
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-status="<?php echo e(strtolower($item->status)); ?>"
                        data-cari="<?php echo e(strtolower($item->lokasi . ' ' . $item->nama_pelapor)); ?>">
                        <td data-label="Tanggal" class="lb-tgl"><?php echo e($item->tanggal_kejadian->format('d M Y')); ?></td>
                        <td data-label="Lokasi" class="lb-lokasi"><?php echo e($item->lokasi); ?></td>
                        <td data-label="Tinggi">
                            <div class="lb-tinggi">
                                <b><?php echo e($item->tinggi_genangan); ?> <small>cm</small></b>
                                <div class="lb-bar">
                                    <i class="bar-<?php echo e(strtolower($item->status)); ?>" style="width: <?php echo e($item->lebar_bar); ?>%"></i>
                                </div>
                            </div>
                        </td>
                        <td data-label="Status">
                            <span class="lb-badge lb-<?php echo e(strtolower($item->status)); ?>"><?php echo e($item->status); ?></span>
                        </td>
                        <td data-label="Pelapor" class="lb-pelapor"><?php echo e($item->nama_pelapor); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr id="lbKosong" style="<?php echo e($jumlah['semua'] ? 'display:none' : ''); ?>">
                    <td colspan="5" class="lb-empty">
                        <?php if($jumlah['semua']): ?>
                            Tidak ada laporan yang cocok.
                        <?php else: ?>
                            Belum ada laporan. <a href="/form">Buat laporan pertama</a>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="lb-foot">
        <span id="lbInfo">Menampilkan <?php echo e($jumlah['semua']); ?> dari <?php echo e($jumlah['semua']); ?> laporan</span>
        <span>Awas ≥ 100 cm &nbsp;·&nbsp; Siaga 50–99 cm &nbsp;·&nbsp; Waspada &lt; 50 cm</span>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/daftar.blade.php ENDPATH**/ ?>