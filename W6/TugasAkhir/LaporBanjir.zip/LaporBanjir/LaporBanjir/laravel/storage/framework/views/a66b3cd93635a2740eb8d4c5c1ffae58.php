<?php $__env->startSection('title', 'Profil Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="formulir sempit <?php echo e(Auth::user()->isAdmin() ? 'masuk-admin' : ''); ?>">
    <div class="formulir-kop">Kartu petugas</div>

    <h1 class="judul-halaman" style="margin-top:0">Profil Petugas</h1>

    <dl>
        <div class="data-baris"><dt>Nama</dt><dd><?php echo e(Auth::user()->name); ?></dd></div>
        <div class="data-baris"><dt>Email</dt><dd><?php echo e(Auth::user()->email); ?></dd></div>
        <div class="data-baris">
            <dt>Peran</dt>
            <dd><span class="peran peran-<?php echo e(Auth::user()->role); ?>"><?php echo e(Auth::user()->role); ?></span></dd>
        </div>
        <div class="data-baris"><dt>Akun dibuat</dt><dd><?php echo e(Auth::user()->created_at->format('d M Y, H:i')); ?></dd></div>
    </dl>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W6\TugasAkhir\LaporBanjir\LaporBanjir\laravel\resources\views/profil.blade.php ENDPATH**/ ?>