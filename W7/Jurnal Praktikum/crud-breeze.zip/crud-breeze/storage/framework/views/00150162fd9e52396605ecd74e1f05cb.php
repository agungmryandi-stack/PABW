
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detail Berkas
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6 space-y-2">

                <p>
                    <strong>Judul:</strong>
                    <?php echo e($upload->judul); ?>

                </p>

                <p>
                    <strong>Keterangan:</strong>
                    <?php echo e($upload->keterangan ?? '-'); ?>

                </p>

                <p>
                    <strong>Nama File:</strong>
                    <?php echo e($upload->filename); ?>

                </p>

                <p>
                    <strong>Diunggah oleh:</strong>
                    <?php echo e($upload->user->name); ?>

                </p>

                <p>
                    <strong>Tanggal Unggah:</strong>
                    <?php echo e($upload->created_at->format('d-m-Y H:i')); ?>

                </p>

                <?php
                    $ext = strtolower(
                        pathinfo($upload->file_path, PATHINFO_EXTENSION)
                    );
                ?>

                
                <?php if(in_array($ext, ['jpg', 'jpeg', 'png'])): ?>
                    <img
                        src="<?php echo e(asset('storage/' . $upload->file_path)); ?>"
                        alt="<?php echo e($upload->judul); ?>"
                        class="max-w-sm rounded border"
                    >
                <?php else: ?>
                    <a
                        href="<?php echo e(asset('storage/' . $upload->file_path)); ?>"
                        target="_blank"
                        class="inline-block px-4 py-2 bg-gray-800 text-white rounded"
                    >
                        Buka / Unduh Berkas
                    </a>
                <?php endif; ?>

                <div class="pt-4">
                    <a
                        href="<?php echo e(route('uploads.edit', $upload)); ?>"
                        class="text-yellow-600"
                    >
                        Edit
                    </a>

                    |

                    <a
                        href="<?php echo e(route('uploads.index')); ?>"
                        class="text-gray-600"
                    >
                        Kembali
                    </a>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W7\crud-breeze\resources\views/uploads/show.blade.php ENDPATH**/ ?>