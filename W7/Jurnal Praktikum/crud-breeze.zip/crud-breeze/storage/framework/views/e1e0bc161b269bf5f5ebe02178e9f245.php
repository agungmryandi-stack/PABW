
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Daftar Berkas
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">

                
                <?php if(session('success')): ?>
                    <div class="mb-4 p-3 rounded bg-green-100 text-green-700">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('uploads.create')); ?>"
                    class="inline-block mb-4 px-4 py-2 bg-blue-600 text-white rounded">
                    + Unggah Berkas
                </a>

                <table class="w-full border text-left">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border p-2">No</th>
                            <th class="border p-2">Judul</th>
                            <th class="border p-2">Nama File</th>
                            <th class="border p-2">Tanggal Unggah</th>
                            <th class="border p-2">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border p-2">
                                    <?php echo e($uploads->firstItem() + $loop->index); ?>

                                </td>

                                <td class="border p-2">
                                    <?php echo e($upload->judul); ?>

                                </td>

                                <td class="border p-2">
                                    
                                    <a href="<?php echo e(asset('storage/' . $upload->file_path)); ?>"
                                        target="_blank"
                                        class="text-blue-600 underline">
                                        <?php echo e($upload->file_name); ?>

                                    </a>
                                </td>

                                <td class="border p-2">
                                    <?php echo e($upload->created_at->format('d-m-Y H:i')); ?>

                                </td>

                                <td class="border p-2">
                                    <a href="<?php echo e(route('uploads.show', $upload)); ?>"
                                        class="text-sky-600">
                                        Lihat
                                    </a>
                                    |

                                    <a href="<?php echo e(route('uploads.edit', $upload)); ?>"
                                        class="text-yellow-600">
                                        Edit
                                    </a>
                                    |

                                    <form action="<?php echo e(route('uploads.destroy', $upload)); ?>"
                                        method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                            class="text-red-600"
                                            onclick="return confirm('Yakin ingin menghapus berkas ini?')">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="border p-2 text-center">
                                    Belum ada berkas yang diunggah.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="mt-4">
                    <?php echo e($uploads->links()); ?>

                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W7\crud-breeze\resources\views/uploads/index.blade.php ENDPATH**/ ?>