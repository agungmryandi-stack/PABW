
<?php $__env->startSection('title', 'Detail Laporan'); ?>

<?php $__env->startSection('content'); ?>
<p class="kecil" style="margin-top:20px">Petugas BPBD &middot; Laporan #<?php echo e($laporan->id); ?></p>
<h1 class="judul-halaman">Detail Laporan</h1>

<div class="kartu-detail">
    <div class="kartu-foto">
        <a href="<?php echo e(asset('storage/' . $laporan->foto)); ?>" target="_blank">
            <img src="<?php echo e(asset('storage/' . $laporan->foto)); ?>" alt="Foto banjir">
        </a>
        <small>Klik foto untuk memperbesar</small>
    </div>

    <div class="kartu-isi">
        <div class="kartu-kepala">
            <h2><?php echo e($laporan->lokasi); ?></h2>
            <span class="lencana lencana-<?php echo e(strtolower($laporan->status)); ?>"><?php echo e($laporan->status); ?></span>
        </div>

        <dl class="info">
            <dt>Pelapor</dt>    <dd><?php echo e($laporan->nama_pelapor); ?></dd>
            <dt>No HP</dt>      <dd><?php echo e($laporan->no_hp); ?></dd>
            <dt>Kecamatan</dt>  <dd><?php echo e($laporan->kecamatan); ?></dd>
            <dt>Tinggi Air</dt> <dd><?php echo e($laporan->tinggi_air); ?> cm</dd>
            <dt>Keterangan</dt> <dd><?php echo e($laporan->keterangan ?? '-'); ?></dd>
            <dt>Dilaporkan</dt> <dd><?php echo e($laporan->created_at->format('d-m-Y H:i')); ?></dd>
        </dl>

        <div class="tombol-baris">
            <a href="<?php echo e(route('laporan.edit', $laporan)); ?>" class="tombol">Edit</a>
            <a href="<?php echo e(route('laporan.index')); ?>" class="tombol tombol-garis">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.laporbanjir', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W7\TugasAkhir\laporBanjir\resources\views/laporan/show.blade.php ENDPATH**/ ?>