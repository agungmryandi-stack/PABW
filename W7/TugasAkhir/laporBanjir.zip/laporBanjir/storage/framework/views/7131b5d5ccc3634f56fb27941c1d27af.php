
<?php $__env->startSection('title', 'Lapor Banjir'); ?>

<?php $__env->startSection('content'); ?>
<div class="dua-kolom">

    <section class="formulir">
        <div class="formulir-kop">Formulir laporan banjir</div>

        
        <form action="<?php echo e(route('laporan.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="isian">
                <label>01 &middot; Nama Pelapor</label>
                <input type="text" name="nama_pelapor" value="<?php echo e(old('nama_pelapor')); ?>" placeholder="Contoh: Budi Santoso">
                <?php $__errorArgs = ['nama_pelapor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>02 &middot; No HP</label>
                <input type="text" name="no_hp" value="<?php echo e(old('no_hp')); ?>" placeholder="Contoh: 081234567890">
                <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>03 &middot; Lokasi (alamat / nama jalan)</label>
                <input type="text" name="lokasi" value="<?php echo e(old('lokasi')); ?>" placeholder="Contoh: Jl. Raya Dayeuhkolot No. 12">
                <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>04 &middot; Kecamatan</label>
                <select name="kecamatan">
                    <option value="">-- Pilih kecamatan --</option>
                    <?php $__currentLoopData = ['Dayeuhkolot', 'Baleendah', 'Bojongsoang', 'Rancaekek', 'Majalaya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kec); ?>" <?php if(old('kecamatan') == $kec): echo 'selected'; endif; ?>><?php echo e($kec); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>05 &middot; Tinggi Air (cm)</label>
                <input type="number" name="tinggi_air" value="<?php echo e(old('tinggi_air')); ?>" placeholder="Contoh: 60">
                <?php $__errorArgs = ['tinggi_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>06 &middot; Keterangan (opsional)</label>
                <textarea name="keterangan" rows="3"><?php echo e(old('keterangan')); ?></textarea>
                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="isian">
                <label>07 &middot; Foto Kondisi Banjir (jpg, jpeg, png - maks. 2 MB)</label>
                <input type="file" name="foto" accept="image/*">
                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="tombol tombol-penuh">Kirim Laporan</button>
        </form>
    </section>

    <aside class="catatan">
        <p class="kecil">Untuk warga</p>
        <h1 class="judul-halaman">Laporkan banjir di sekitar Anda.</h1>
        <p class="lead">Tidak perlu login. Sertakan foto kondisi banjir sebagai bukti agar petugas BPBD dapat menilai tingkat bahayanya.</p>
        <p style="margin-top:14px">Ukur tinggi air dari permukaan tanah ke batas air terdalam yang terlihat.</p>
    </aside>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.laporbanjir', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W7\TugasAkhir\laporBanjir\resources\views/laporan/create.blade.php ENDPATH**/ ?>