
<?php $__env->startSection('title', 'Daftar Laporan'); ?>

<?php $__env->startSection('content'); ?>
<p class="kecil" style="margin-top:20px">Petugas BPBD</p>
<h1 class="judul-halaman">Daftar Laporan Banjir</h1>

<div class="tabel-bungkus" style="margin-top:20px">
    <table class="tabel">
        <thead>
            <tr>
                <th>No</th><th>Foto</th><th>Pelapor</th><th>Lokasi</th>
                <th>Kecamatan</th><th>Tinggi Air</th><th>Status</th><th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($laporans->firstItem() + $loop->index); ?></td>
                    <td><img src="<?php echo e(asset('storage/' . $laporan->foto)); ?>" alt="Foto banjir" class="thumb"></td>
                    <td><?php echo e($laporan->nama_pelapor); ?></td>
                    <td><?php echo e($laporan->lokasi); ?></td>
                    <td><?php echo e($laporan->kecamatan); ?></td>
                    <td><?php echo e($laporan->tinggi_air); ?> cm</td>
                    <td><span class="lencana lencana-<?php echo e(strtolower($laporan->status)); ?>"><?php echo e($laporan->status); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('laporan.show', $laporan)); ?>" class="link-aksi">Lihat</a> |
                        <a href="<?php echo e(route('laporan.edit', $laporan)); ?>" class="link-aksi">Edit</a> |
                        <form action="<?php echo e(route('laporan.destroy', $laporan)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="link-aksi link-hapus"
                                onclick="return confirm('Yakin ingin menghapus laporan ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" style="text-align:center">Belum ada laporan masuk.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($laporans->links('pagination::default')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.laporbanjir', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W7\TugasAkhir\laporBanjir\resources\views/laporan/index.blade.php ENDPATH**/ ?>