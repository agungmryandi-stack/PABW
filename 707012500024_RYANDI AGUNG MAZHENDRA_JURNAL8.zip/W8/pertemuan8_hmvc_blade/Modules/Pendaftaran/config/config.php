<?php

return [
    'name' => 'Pendaftaran',
];
